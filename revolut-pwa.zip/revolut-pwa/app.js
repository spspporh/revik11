// ==========================================================================
// REVOLUT iOS PWA CORE LOGIC
// ==========================================================================

const STORAGE_KEYS = {
  BALANCE: 'revolut_pwa_balance',
  USER_NAME: 'revolut_pwa_user_name',
  CURRENCY: 'revolut_pwa_currency',
  ACCOUNT_INFO: 'revolut_pwa_account_info',
  AVATAR: 'revolut_pwa_avatar',
  TRANSACTIONS: 'revolut_pwa_transactions',
  ESIM_CLOSED: 'revolut_pwa_esim_closed'
};

// Initial State (British IBAN and British Recent Payments)
const savedTx = JSON.parse(localStorage.getItem(STORAGE_KEYS.TRANSACTIONS) || 'null');
const defaultTx = [
  {
    id: 'tx-oliver',
    title: 'Oliver Smith',
    subtitle: 'Today, 12:15 · Lunch',
    amount: -42.50,
    type: 'outgoing',
    initial: 'OS'
  },
  {
    id: 'tx-charlotte',
    title: 'Charlotte Davies',
    subtitle: 'Yesterday, 18:30',
    amount: 250.00,
    type: 'incoming',
    initial: 'CD'
  },
  {
    id: 'tx-archie',
    title: 'Archie Harrison',
    subtitle: 'Nov 15, 09:40 · Coffee & snacks',
    amount: -18.00,
    type: 'outgoing',
    initial: 'AH'
  }
];

let initialTx = defaultTx;
if (savedTx && Array.isArray(savedTx) && savedTx.length > 0) {
  // Filter out any previous sample placeholders (Eleanor, Girafa, Monika)
  const userMadeTx = savedTx.filter(t => !['tx-1', 'tx-2', 'tx-girafa', 'tx-monika'].includes(t.id));
  if (userMadeTx.length > 0) {
    initialTx = [...userMadeTx, ...defaultTx];
  } else {
    initialTx = defaultTx;
  }
}

// Account Info (Default British Revolut IBAN)
let savedAccount = localStorage.getItem(STORAGE_KEYS.ACCOUNT_INFO);
if (!savedAccount || savedAccount.startsWith('LT') || savedAccount.includes('04-00-76 · Acc 95352532')) {
  savedAccount = 'GB29 REVO 0400 7620 5832 19';
  localStorage.setItem(STORAGE_KEYS.ACCOUNT_INFO, savedAccount);
}

let appState = {
  balance: parseFloat(localStorage.getItem(STORAGE_KEYS.BALANCE) ?? '0.99'),
  userName: localStorage.getItem(STORAGE_KEYS.USER_NAME) || 'OP',
  currency: localStorage.getItem(STORAGE_KEYS.CURRENCY) || '£',
  accountInfo: savedAccount,
  avatar: localStorage.getItem(STORAGE_KEYS.AVATAR) || '',
  transactions: initialTx
};

// DOM Elements
const balanceDisplay = document.getElementById('balanceDisplay');
const profileName = document.getElementById('profileName');
const profileAvatar = document.getElementById('profileAvatar');
const profileInitialsDisplay = document.getElementById('profileInitialsDisplay');
const accountInfoText = document.getElementById('accountInfoText');
const transactionsList = document.getElementById('transactionsList');
const esimBanner = document.getElementById('esimBanner');
const toastEl = document.getElementById('toast');
const totalWealthDisplay = document.getElementById('totalWealthDisplay');
const cashBalanceDisplay = document.getElementById('cashBalanceDisplay');

// Modals & Backdrops
const addMoneySheetBackdrop = document.getElementById('addMoneySheetBackdrop');
const settingsSheetBackdrop = document.getElementById('settingsSheetBackdrop');
const addMoneyInput = document.getElementById('addMoneyInput');
const addMoneyCurrencyPrefix = document.getElementById('addMoneyCurrencyPrefix');

// Inputs in Settings
const inputUserName = document.getElementById('inputUserName');
const inputCurrency = document.getElementById('inputCurrency');
const inputDirectBalance = document.getElementById('inputDirectBalance');
const inputAccountInfo = document.getElementById('inputAccountInfo');
const settingsAvatarPreview = document.getElementById('settingsAvatarPreview');
const avatarFileInput = document.getElementById('avatarFileInput');

// Format Currency
function formatAmount(num, currency = appState.currency) {
  const parts = num.toLocaleString('en-GB', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).split('.');
  return {
    whole: `${currency}${parts[0]}`,
    cents: `.${parts[1]}`
  };
}

// Render Balance
function renderBalance() {
  const formatted = formatAmount(appState.balance);
  balanceDisplay.innerHTML = `${formatted.whole}<span class="cents">${formatted.cents}</span>`;
  addMoneyCurrencyPrefix.textContent = appState.currency;
  // Total wealth / Cash were hard-coded to £24 before; now they follow the balance
  const cashStr = `${formatted.whole}${formatted.cents}`;
  if (totalWealthDisplay) totalWealthDisplay.textContent = cashStr;
  if (cashBalanceDisplay) cashBalanceDisplay.textContent = cashStr;
}

// Render User & Account Info
function renderUserInfo() {
  if (profileName) profileName.textContent = appState.userName;
  if (profileInitialsDisplay) {
    const initials = appState.userName.trim().slice(0, 2).toUpperCase() || 'OP';
    profileInitialsDisplay.textContent = initials;
  }
  if (accountInfoText) accountInfoText.textContent = appState.accountInfo;

  if (appState.avatar) {
    if (profileAvatar) profileAvatar.src = appState.avatar;
    if (settingsAvatarPreview) settingsAvatarPreview.src = appState.avatar;
  }
}

// Render Transactions
function renderTransactions() {
  if (!transactionsList) return;
  transactionsList.innerHTML = '';
  
  appState.transactions.forEach((tx) => {
    const isPositive = tx.amount > 0;
    const sign = isPositive ? '+' : '-';
    const absVal = Math.abs(tx.amount).toLocaleString('en-GB', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2
    });
    const amountStr = `${sign}${appState.currency}${absVal}`;
    const amountClass = isPositive ? 'tx-positive' : 'tx-negative';

    const item = document.createElement('div');
    item.className = 'transaction-item';
    item.dataset.id = tx.id;

    let badgeHtml = '';
    if (tx.type === 'outgoing' || (!isPositive && tx.type !== 'topup')) {
      badgeHtml = `<span class="tx-badge-icon tx-badge-outgoing">➔</span>`;
    } else if (tx.type === 'incoming' || isPositive) {
      badgeHtml = `<span class="tx-badge-icon tx-badge-incoming">+</span>`;
    }

    let avatarHtml = '';
    if (tx.type === 'topup') {
      avatarHtml = `
        <div class="tx-avatar tx-avatar-icon purple-tx-avatar">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="2" y="5" width="20" height="14" rx="3"/>
            <line x1="2" y1="10" x2="22" y2="10"/>
          </svg>
          ${badgeHtml}
        </div>`;
    } else {
      const initial = tx.initial || (tx.title ? tx.title.slice(0, 2).toUpperCase() : 'TX');
      avatarHtml = `
        <div class="tx-avatar tx-avatar-initial purple-tx-avatar">
          ${initial}
          ${badgeHtml}
        </div>`;
    }

    const formattedSubtitle = (tx.subtitle || '').replace(/\n/g, '<br>');

    item.innerHTML = `
      ${avatarHtml}
      <div class="tx-info">
        <div class="tx-title">${tx.title}</div>
        <div class="tx-subtitle">${formattedSubtitle}</div>
      </div>
      <div class="tx-amount ${amountClass}">${amountStr}</div>
    `;

    item.addEventListener('click', () => {
      showToast(`${tx.title}: ${amountStr}`);
    });

    transactionsList.appendChild(item);
  });
}

// Toast Helper
let toastTimeout;
function showToast(msg) {
  if (navigator.vibrate) navigator.vibrate(15);
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => {
    toastEl.classList.remove('show');
  }, 2200);
}

// Modal Handlers
function openAddMoneyModal() {
  if (navigator.vibrate) navigator.vibrate(10);
  addMoneyInput.value = '';
  addMoneySheetBackdrop.classList.add('open');
  // Must be called synchronously inside the tap handler, otherwise iOS will not show the keyboard
  addMoneyInput.focus({ preventScroll: true });
}

function closeAddMoneyModal() {
  addMoneySheetBackdrop.classList.remove('open');
  addMoneyInput.blur();
}

function openSettingsModal() {
  if (navigator.vibrate) navigator.vibrate(10);
  inputUserName.value = appState.userName;
  inputCurrency.value = appState.currency;
  inputDirectBalance.value = appState.balance.toFixed(2);
  inputAccountInfo.value = appState.accountInfo;
  settingsSheetBackdrop.classList.add('open');
}

function closeSettingsModal() {
  settingsSheetBackdrop.classList.remove('open');
}

// Event Listeners
document.getElementById('addMoneyBtn').addEventListener('click', openAddMoneyModal);
document.getElementById('closeAddMoneyBtn').addEventListener('click', closeAddMoneyModal);
addMoneySheetBackdrop.addEventListener('click', (e) => {
  if (e.target === addMoneySheetBackdrop) closeAddMoneyModal();
});

// Quick Chips in Add Money
document.querySelectorAll('.chip-btn').forEach((chip) => {
  chip.addEventListener('click', () => {
    const val = parseFloat(chip.dataset.val);
    const curr = parseFloat(addMoneyInput.value || 0) || 0;
    addMoneyInput.value = String(+(curr + val).toFixed(2));
    addMoneyInput.focus({ preventScroll: true });
  });
});

// Native decimal keypad: accept only digits and one dot (iOS may type a comma in some locales)
addMoneyInput.addEventListener('input', () => {
  addMoneyInput.value = sanitizeAmount(addMoneyInput.value);
});

// Confirm Add Money
document.getElementById('confirmAddMoneyBtn').addEventListener('click', () => {
  const amountToAdd = parseFloat(addMoneyInput.value);
  if (isNaN(amountToAdd) || amountToAdd <= 0) {
    showToast('Please enter a valid amount');
    return;
  }

  // Update Balance
  appState.balance += amountToAdd;
  localStorage.setItem(STORAGE_KEYS.BALANCE, appState.balance.toString());

  // Add Transaction
  const now = new Date();
  const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const newTx = {
    id: 'tx-' + Date.now(),
    title: 'Top-up by Apple Pay',
    subtitle: `Today, ${timeStr}`,
    amount: amountToAdd,
    type: 'topup',
    initial: ''
  };

  appState.transactions.unshift(newTx);
  localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(appState.transactions));

  renderBalance();
  renderTransactions();
  closeAddMoneyModal();
  showToast(`Added ${appState.currency}${amountToAdd.toLocaleString('en-GB', { minimumFractionDigits: 2 })}!`);
});

// Settings & Profile
document.getElementById('profileBtn').addEventListener('click', openSettingsModal);
document.getElementById('closeSettingsBtn').addEventListener('click', closeSettingsModal);
settingsSheetBackdrop.addEventListener('click', (e) => {
  if (e.target === settingsSheetBackdrop) closeSettingsModal();
});

// Avatar Upload
avatarFileInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = (event) => {
      appState.avatar = event.target.result;
      settingsAvatarPreview.src = appState.avatar;
      updateDynamicProfile();
      try {
        localStorage.setItem(STORAGE_KEYS.AVATAR, appState.avatar);
        showToast('Photo updated');
      } catch (err) {
        showToast('Photo is too large to save');
      }
    };
    reader.readAsDataURL(file);
  }
});

// Save Settings
document.getElementById('saveSettingsBtn').addEventListener('click', () => {
  const newName = inputUserName.value.trim();
  const newCurrency = inputCurrency.value.trim() || '£';
  const newDirectBal = parseFloat(inputDirectBalance.value);
  const newAccInfo = inputAccountInfo.value.trim();

  if (newName) appState.userName = newName;
  appState.currency = newCurrency;
  if (!isNaN(newDirectBal) && newDirectBal >= 0) appState.balance = newDirectBal;
  if (newAccInfo) appState.accountInfo = newAccInfo;

  localStorage.setItem(STORAGE_KEYS.USER_NAME, appState.userName);
  localStorage.setItem(STORAGE_KEYS.CURRENCY, appState.currency);
  localStorage.setItem(STORAGE_KEYS.BALANCE, appState.balance.toString());
  localStorage.setItem(STORAGE_KEYS.ACCOUNT_INFO, appState.accountInfo);

  renderUserInfo();
  updateDynamicProfile();
  renderBalance();
  renderTransactions();
  closeSettingsModal();
  showToast('Profile saved');
});

// Reset Balance
document.getElementById('resetBalanceBtn').addEventListener('click', () => {
  appState.balance = 0.00;
  localStorage.setItem(STORAGE_KEYS.BALANCE, '0.00');
  inputDirectBalance.value = '0.00';
  renderBalance();
  showToast('Balance reset to 0');
});

// eSIM Banner Close (safe check)
if (esimBanner && localStorage.getItem(STORAGE_KEYS.ESIM_CLOSED) === 'true') {
  esimBanner.style.display = 'none';
}
const closeBannerBtn = document.getElementById('closeBannerBtn');
if (closeBannerBtn && esimBanner) {
  closeBannerBtn.addEventListener('click', () => {
    esimBanner.style.display = 'none';
    localStorage.setItem(STORAGE_KEYS.ESIM_CLOSED, 'true');
  });
}

// Quick Action Buttons
document.getElementById('moveBtn').addEventListener('click', () => {
  openPayments();
});

document.getElementById('detailsActionBtn').addEventListener('click', () => {
  showToast(`Account: ${appState.accountInfo}`);
});

document.getElementById('detailsPill').addEventListener('click', () => {
  showToast(`Copied: ${appState.accountInfo}`);
});

document.getElementById('moreBtn').addEventListener('click', () => {
  showToast('More options opened');
});

document.getElementById('seeAllBtn').addEventListener('click', () => {
  showToast('Opening all transactions...');
});

// Bottom Navigation Switching
document.querySelectorAll('.nav-item').forEach((item) => {
  item.addEventListener('click', () => {
    const tab = item.dataset.tab;
    if (tab === 'payments') {
      openPayments();
      return;
    }
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    item.classList.add('active');
    if (tab !== 'home') {
      showToast(`Tab: ${item.querySelector('.nav-label').textContent}`);
    }
  });
});

// ==========================================================================
// PAYMENTS & TRANSFER FLOW (SCREENSHOTS 1, 2, 3)
// ==========================================================================

const paymentsView = document.getElementById('paymentsView');
const transferView = document.getElementById('transferView');
const closePaymentsBtn = document.getElementById('closePaymentsBtn');
const paymentSearchInput = document.getElementById('paymentSearchInput');
const clearSearchBtn = document.getElementById('clearSearchBtn');
const qrScanBtn = document.getElementById('qrScanBtn');
const paymentMainContent = document.getElementById('paymentMainContent');
const searchResultsContainer = document.getElementById('searchResultsContainer');

// Transfer View Elements
const backFromTransferBtn = document.getElementById('backFromTransferBtn');
const transferRecipientName = document.getElementById('transferRecipientName');
const transferRecipientTag = document.getElementById('transferRecipientTag');
const transferRecipientAvatar = document.getElementById('transferRecipientAvatar');
const transferAmountDisplay = document.getElementById('transferAmountDisplay');
const transferAmountInput = document.getElementById('transferAmountInput');
const transferAmountField = document.getElementById('transferAmountField');
const sourceBalanceText = document.getElementById('sourceBalanceText');
const continueTransferBtn = document.getElementById('continueTransferBtn');
const transferNoteInput = document.getElementById('transferNoteInput');

let currentRecipient = {
  name: 'Noah Ellis',
  tag: '@philippslp',
  initial: 'NE',
  hasPhoto: false
};
let transferAmountRaw = '0';

function updateDynamicProfile() {
  document.querySelectorAll('.dynamic-profile-name').forEach(el => el.textContent = appState.userName);
  if (appState.avatar) {
    document.querySelectorAll('.dynamic-profile-avatar').forEach(el => el.src = appState.avatar);
  }
}

function openPayments() {
  if (navigator.vibrate) navigator.vibrate(10);
  updateDynamicProfile();
  paymentsView.classList.add('active');
  showFreshPayments();
}

// New Payment page in its initial state: empty search, default content, scrolled to top
function showFreshPayments() {
  resetPaymentSearch();
  renderRecents();
  paymentMainContent.scrollTop = 0;
}

function closePayments() {
  paymentsView.classList.remove('active');
  resetPaymentSearch();
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.querySelector('.nav-item[data-tab="home"]').classList.add('active');
}

closePaymentsBtn.addEventListener('click', closePayments);

// Search Handling & iOS Keyboard Simulation
const dynamicUserRow = document.getElementById('dynamicUserRow');
const dynamicName = document.getElementById('dynamicName');
const dynamicTag = document.getElementById('dynamicTag');
const dynamicInitialText = document.getElementById('dynamicInitialText');

let currentSearchUser = null;

function getSearchUserInfo(rawQuery) {
  const raw = rawQuery.trim();
  if (!raw) return null;
  const tag = raw.startsWith('@') ? raw : `@${raw}`;
  const plain = raw.startsWith('@') ? raw.slice(1) : raw;
  const name = plain ? (plain.charAt(0).toUpperCase() + plain.slice(1)) : 'User';
  const initial = plain ? plain.slice(0, 2).toUpperCase() : 'U';
  return { name, tag, initial, hasPhoto: false };
}

function handleSearchInput(query) {
  const raw = query.trim();
  const q = raw.toLowerCase();

  if (raw.length > 0) {
    clearSearchBtn.classList.add('show');
    qrScanBtn.style.display = 'none';
    paymentMainContent.style.display = 'none';
    searchResultsContainer.classList.add('active');

    // Dynamic User card for ANY random nickname entered!
    currentSearchUser = getSearchUserInfo(raw);
    dynamicName.textContent = currentSearchUser.name;
    dynamicTag.textContent = `${currentSearchUser.tag} · Revolut user`;
    dynamicInitialText.textContent = currentSearchUser.initial;
    dynamicUserRow.style.display = 'flex';

    dynamicUserRow.onclick = () => {
      openChatView(currentSearchUser);
    };

    // Filter predefined contacts
    const matchJacob = 'jacob chandler @philipmccrabbe phili'.includes(q);
    const matchNoah = 'noah ellis @philippslp phili'.includes(q);

    document.getElementById('jacobChandlerRow').style.display = matchJacob || q.includes('phil') ? 'flex' : (q ? 'none' : 'flex');
    document.getElementById('noahEllisRow').style.display = matchNoah || q.includes('noah') || q.includes('phil') ? 'flex' : (q ? 'none' : 'flex');
  } else {
    currentSearchUser = null;
    clearSearchBtn.classList.remove('show');
    qrScanBtn.style.display = 'flex';
    paymentMainContent.style.display = 'block';
    searchResultsContainer.classList.remove('active');
    dynamicUserRow.style.display = 'none';
  }
}

paymentSearchInput.addEventListener('input', (e) => {
  handleSearchInput(e.target.value);
});

paymentSearchInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    if (currentSearchUser) {
      openChatView(currentSearchUser);
    }
  }
});

clearSearchBtn.addEventListener('click', () => {
  paymentSearchInput.value = '';
  handleSearchInput('');
  paymentSearchInput.focus();
});

function resetPaymentSearch() {
  paymentSearchInput.value = '';
  handleSearchInput('');
  paymentSearchInput.blur();
}

// Contact Click Handlers (opens Chat View first)
function setupContactClicks() {
  document.querySelectorAll('.contact-row').forEach((row) => {
    row.addEventListener('click', () => {
      const name = row.dataset.name || 'Noah Ellis';
      const tag = row.dataset.tag || '@philippslp';
      const initial = row.dataset.initial || 'NE';
      const hasPhoto = row.dataset.hasphoto === 'true';

      openChatView({ name, tag, initial, hasPhoto });
    });
  });
}
setupContactClicks();

// Open Transfer Screen (Screenshot 3)
function openTransfer(recipient) {
  if (navigator.vibrate) navigator.vibrate(10);
  currentRecipient = recipient || currentRecipient || {
    name: 'Noah Ellis',
    tag: '@philippslp',
    initial: 'NE',
    hasPhoto: false
  };

  transferRecipientName.textContent = currentRecipient.name;
  transferRecipientTag.textContent = currentRecipient.tag;

  if (currentRecipient.hasPhoto) {
    transferRecipientAvatar.innerHTML = `
      <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23344030'/%3E%3Ccircle cx='50' cy='42' r='20' fill='%23d4a373'/%3E%3Cpath d='M30 46c0 12 9 20 20 20s20-8 20-20z' fill='%2358311a'/%3E%3Cpath d='M30 32c0-8 9-14 20-14s20 6 20 14z' fill='%23283618'/%3E%3Cpath d='M25 90c0-16 12-26 25-26s25 10 25 26z' fill='%23283618'/%3E%3C/svg%3E" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">
    `;
  } else {
    transferRecipientAvatar.textContent = currentRecipient.initial || 'NE';
  }

  // Update Source Balance
  const formattedBal = formatAmount(appState.balance);
  sourceBalanceText.textContent = `Personal · ${formattedBal.whole}${formattedBal.cents}`;

  // Reset Amount
  transferNoteInput.value = '';
  setTransferAmount('');

  transferView.classList.add('active');

  // Native iPhone numeric (decimal) keyboard for the amount.
  // Called synchronously from the tap handler so iOS allows the keyboard to open.
  transferAmountInput.focus({ preventScroll: true });
}

function closeTransfer() {
  transferAmountInput.blur();
  transferNoteInput.blur();
  transferView.classList.remove('active');
}

backFromTransferBtn.addEventListener('click', closeTransfer);

// Render Transfer Amount Display
function renderTransferAmount() {
  transferAmountDisplay.textContent = `${appState.currency}${transferAmountRaw}`;
  transferAmountDisplay.classList.toggle('long', transferAmountRaw.length > 8);
  const numVal = parseFloat(transferAmountRaw);
  if (!isNaN(numVal) && numVal > 0) {
    continueTransferBtn.removeAttribute('disabled');
  } else {
    continueTransferBtn.setAttribute('disabled', 'true');
  }
}

// Keep only digits + one dot, max 2 decimals, max 7 integer digits, no leading zeros
function sanitizeAmount(raw) {
  let v = String(raw).replace(/,/g, '.').replace(/[^0-9.]/g, '');
  const dot = v.indexOf('.');
  if (dot !== -1) {
    const intPart = v.slice(0, dot).replace(/^0+(?=\d)/, '').slice(0, 7) || '0';
    const decPart = v.slice(dot + 1).replace(/\./g, '').slice(0, 2);
    return `${intPart}.${decPart}`;
  }
  return v.replace(/^0+(?=\d)/, '').slice(0, 7);
}

function setTransferAmount(value) {
  const clean = sanitizeAmount(value);
  transferAmountRaw = clean === '' ? '0' : clean;
  transferAmountInput.value = clean;
  renderTransferAmount();
}

// Native keyboard input for the amount (decimal pad: digits only)
transferAmountInput.addEventListener('input', () => {
  setTransferAmount(transferAmountInput.value);
});

transferAmountInput.addEventListener('focus', () => transferAmountField.classList.add('focused'));
transferAmountInput.addEventListener('blur', () => transferAmountField.classList.remove('focused'));

// Hardware / "next" key on the amount moves to the note (letters keyboard)
transferAmountInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    transferNoteInput.focus();
  }
});

// Enter on the note just closes the keyboard
transferNoteInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    transferNoteInput.blur();
  }
});

// Quick Chips in Transfer
document.querySelectorAll('.transfer-chip').forEach((chip) => {
  chip.addEventListener('click', () => {
    if (navigator.vibrate) navigator.vibrate(8);
    setTransferAmount(chip.dataset.amount);
    transferAmountInput.focus({ preventScroll: true });
  });
});

// ==========================================================================
// CHAT & PAYMENT THREAD FLOW (NEW SCREENSHOTS 1 & 2)
// ==========================================================================
const CHAT_STORAGE_KEY = 'revolut_pwa_chat_history';
let chatHistories = JSON.parse(localStorage.getItem(CHAT_STORAGE_KEY) || '{}');

const chatView = document.getElementById('chatView');
const chatBody = document.getElementById('chatBody');
const backFromChatBtn = document.getElementById('backFromChatBtn');
const chatRecipientName = document.getElementById('chatRecipientName');
const chatRecipientTag = document.getElementById('chatRecipientTag');
const chatRecipientMiniAvatar = document.getElementById('chatRecipientMiniAvatar');
const chatContactHero = document.getElementById('chatContactHero');
const chatLargeAvatar = document.getElementById('chatLargeAvatar');
const chatHeroName = document.getElementById('chatHeroName');
const chatHeroTag = document.getElementById('chatHeroTag');
const chatMessagesContainer = document.getElementById('chatMessagesContainer');
const chatDateSeparator = document.getElementById('chatDateSeparator');
const paymentSentBubble = document.getElementById('paymentSentBubble');
const chatSendBtn = document.getElementById('chatSendBtn');
const chatRequestBtn = document.getElementById('chatRequestBtn');
const chatTextInput = document.getElementById('chatTextInput');
const sendTextMessageBtn = document.getElementById('sendTextMessageBtn');

function escapeHtml(str) {
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}

function saveChatHistory() {
  localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(chatHistories));
}

function renderChatHistoryForCurrentRecipient() {
  // Clear all dynamically appended message bubbles
  document.querySelectorAll('.payment-sent-bubble:not(#paymentSentBubble)').forEach(b => b.remove());
  document.querySelectorAll('.user-text-bubble').forEach(b => b.remove());
  if (paymentSentBubble) paymentSentBubble.style.display = 'none';

  const history = chatHistories[currentRecipient.tag] || [];

  if (history.length > 0) {
    chatContactHero.classList.add('compact');
    chatDateSeparator.style.display = 'block';

    history.forEach((msg) => {
      if (msg.type === 'payment') {
        const bubble = document.createElement('div');
        bubble.className = 'payment-sent-bubble';
        bubble.innerHTML = `
          <div class="bubble-header">
            <span class="bubble-arrow">→</span>
            <span>You sent</span>
          </div>
          <div class="bubble-amount">${appState.currency}${msg.amount.toLocaleString('en-GB')}</div>
          ${msg.note ? `<div class="bubble-note">${escapeHtml(msg.note)}</div>` : ''}
          <div class="bubble-time">${msg.time}</div>
        `;
        chatMessagesContainer.appendChild(bubble);
      } else if (msg.type === 'text') {
        const bubble = document.createElement('div');
        bubble.className = 'user-text-bubble';
        bubble.textContent = msg.text;
        chatMessagesContainer.appendChild(bubble);
      }
    });

    setTimeout(() => {
      chatBody.scrollTop = chatBody.scrollHeight;
    }, 50);
  } else {
    chatContactHero.classList.remove('compact');
    chatDateSeparator.style.display = 'none';
  }
}

function openChatView(recipient) {
  if (navigator.vibrate) navigator.vibrate(10);
  currentRecipient = recipient || {
    name: 'Noah Ellis',
    tag: '@philippslp',
    initial: 'NE',
    hasPhoto: false
  };

  // Populate recipient details
  chatRecipientName.textContent = currentRecipient.name;
  chatRecipientTag.textContent = currentRecipient.tag;
  chatHeroName.textContent = currentRecipient.name;
  chatHeroTag.textContent = currentRecipient.tag;

  if (currentRecipient.hasPhoto) {
    const photoHtml = `<img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23344030'/%3E%3Ccircle cx='50' cy='42' r='20' fill='%23d4a373'/%3E%3Cpath d='M30 46c0 12 9 20 20 20s20-8 20-20z' fill='%2358311a'/%3E%3Cpath d='M30 32c0-8 9-14 20-14s20 6 20 14z' fill='%23283618'/%3E%3Cpath d='M25 90c0-16 12-26 25-26s25 10 25 26z' fill='%23283618'/%3E%3C/svg%3E" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
    chatLargeAvatar.innerHTML = photoHtml;
    chatRecipientMiniAvatar.innerHTML = photoHtml;
  } else {
    chatLargeAvatar.textContent = currentRecipient.initial || 'NE';
    chatRecipientMiniAvatar.textContent = currentRecipient.initial || 'NE';
  }

  // Render chat history for this contact (all old and new payment messages preserved)
  renderChatHistoryForCurrentRecipient();

  // Show chatView
  chatView.classList.add('active');
}

// When clicking "→ Send" button in Chat -> opens Transfer screen to enter amount and note!
chatSendBtn.addEventListener('click', (e) => {
  e.preventDefault();
  openTransfer(currentRecipient);
});

// When clicking continue on Transfer screen (Keypad) -> sends payment & appends a NEW payment message!
let isSendingPayment = false;
continueTransferBtn.addEventListener('click', () => {
  const amountToSend = parseFloat(transferAmountRaw);
  if (isNaN(amountToSend) || amountToSend <= 0 || isSendingPayment) return;

  // Minimum 1 second "processing" state before the payment goes through
  isSendingPayment = true;
  continueTransferBtn.classList.add('loading');
  transferView.classList.add('sending');
  transferAmountInput.blur();
  transferNoteInput.blur();

  setTimeout(() => {
    finishPayment(amountToSend);
    isSendingPayment = false;
    continueTransferBtn.classList.remove('loading');
    transferView.classList.remove('sending');
  }, 1000);
});

function finishPayment(amountToSend) {
  if (navigator.vibrate) navigator.vibrate([15, 50, 20]);

  // Deduct from Balance
  appState.balance -= amountToSend;
  localStorage.setItem(STORAGE_KEYS.BALANCE, appState.balance.toString());

  // Add Outgoing Transaction to home
  const now = new Date();
  const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const noteText = transferNoteInput.value.trim();

  const newTx = {
    id: 'tx-' + Date.now(),
    title: currentRecipient.name,
    subtitle: `Today, ${timeStr}${noteText ? ' · ' + noteText : ''}`,
    amount: -amountToSend,
    type: 'outgoing',
    initial: currentRecipient.initial || currentRecipient.name.slice(0, 2).toUpperCase()
  };

  appState.transactions.unshift(newTx);
  localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(appState.transactions));

  renderBalance();
  renderTransactions();

  // Close Transfer screen, returning to Chat Screen
  closeTransfer();

  // Save new payment message into history (so old messages NEVER disappear!)
  if (!chatHistories[currentRecipient.tag]) {
    chatHistories[currentRecipient.tag] = [];
  }
  chatHistories[currentRecipient.tag].push({
    type: 'payment',
    amount: amountToSend,
    note: noteText,
    time: timeStr
  });
  saveChatHistory();
  rememberRecipient(currentRecipient);

  // Animate and append NEW payment message bubble into chat
  chatContactHero.classList.add('compact');
  chatDateSeparator.style.display = 'block';

  const newBubble = document.createElement('div');
  newBubble.className = 'payment-sent-bubble';
  newBubble.innerHTML = `
    <div class="bubble-header">
      <span class="bubble-arrow">→</span>
      <span>You sent</span>
    </div>
    <div class="bubble-amount">${appState.currency}${amountToSend.toLocaleString('en-GB')}</div>
    ${noteText ? `<div class="bubble-note">${escapeHtml(noteText)}</div>` : ''}
    <div class="bubble-time">${timeStr}</div>
  `;
  chatMessagesContainer.appendChild(newBubble);

  // Smooth scroll to the newest message
  setTimeout(() => {
    chatBody.scrollTo({ top: chatBody.scrollHeight, behavior: 'smooth' });
  }, 50);

  showToast(`Sent ${appState.currency}${amountToSend.toLocaleString('en-GB')} to ${currentRecipient.name}!`);
}

// Back from Chat Button -> per user request: returns to paymentsView
backFromChatBtn.addEventListener('click', () => {
  chatTextInput.blur();
  chatView.classList.remove('active');
  closeTransfer();
  showFreshPayments(); // back to a clean "New payment" page (no nickname typed)
});

// Request Button in Chat
chatRequestBtn.addEventListener('click', () => {
  showToast(`Request sent to ${currentRecipient.name}`);
});

// Sending text messages in chat
function sendTextMessage() {
  const text = chatTextInput.value.trim();
  if (!text) return;
  const now = new Date();
  const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  if (!chatHistories[currentRecipient.tag]) {
    chatHistories[currentRecipient.tag] = [];
  }
  chatHistories[currentRecipient.tag].push({
    type: 'text',
    text: text,
    time: timeStr
  });
  saveChatHistory();

  chatDateSeparator.style.display = 'block';
  chatContactHero.classList.add('compact');
  const bubble = document.createElement('div');
  bubble.className = 'user-text-bubble';
  bubble.textContent = text;
  chatMessagesContainer.appendChild(bubble);
  chatTextInput.value = '';

  setTimeout(() => {
    chatBody.scrollTo({ top: chatBody.scrollHeight, behavior: 'smooth' });
  }, 50);
}
sendTextMessageBtn.addEventListener('click', sendTextMessage);
chatTextInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    sendTextMessage();
  }
});

// ==========================================================================
// RECENT RECIPIENTS (history of people you already sent money to)
// ==========================================================================
const RECIPIENTS_KEY = 'revolut_pwa_recipients';
const JACOB_PHOTO_SRC = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23344030'/%3E%3Ccircle cx='50' cy='42' r='20' fill='%23d4a373'/%3E%3Cpath d='M30 46c0 12 9 20 20 20s20-8 20-20z' fill='%2358311a'/%3E%3Cpath d='M30 32c0-8 9-14 20-14s20 6 20 14z' fill='%23283618'/%3E%3Cpath d='M25 90c0-16 12-26 25-26s25 10 25 26z' fill='%23283618'/%3E%3C/svg%3E";

let recents = [];
try {
  recents = JSON.parse(localStorage.getItem(RECIPIENTS_KEY) || '[]');
  if (!Array.isArray(recents)) recents = [];
} catch (e) {
  recents = [];
}

function rememberRecipient(r) {
  if (!r || !r.tag) return;
  recents = recents.filter((x) => x.tag !== r.tag);
  recents.unshift({
    name: r.name,
    tag: r.tag,
    initial: r.initial || (r.name || '?').slice(0, 2).toUpperCase(),
    hasPhoto: !!r.hasPhoto
  });
  recents = recents.slice(0, 20);
  try { localStorage.setItem(RECIPIENTS_KEY, JSON.stringify(recents)); } catch (e) { /* ignore */ }
}

function renderRecents() {
  const section = document.getElementById('recentSection');
  const list = document.getElementById('recentList');
  if (!section || !list) return;

  // Payments made before this feature existed: add their recipients too
  Object.keys(chatHistories).forEach((tag) => {
    const hasPayment = (chatHistories[tag] || []).some((m) => m.type === 'payment');
    if (hasPayment && !recents.some((r) => r.tag === tag)) {
      const info = getSearchUserInfo(tag);
      if (info) recents.push(info);
    }
  });

  list.innerHTML = '';
  let shown = 0;

  recents.forEach((r) => {
    const payments = (chatHistories[r.tag] || []).filter((m) => m.type === 'payment');
    if (payments.length === 0) return;
    const last = payments[payments.length - 1];
    shown++;

    const row = document.createElement('div');
    row.className = 'contact-row';

    const avatar = document.createElement('div');
    avatar.className = r.hasPhoto ? 'contact-avatar photo-avatar' : 'contact-avatar contact-avatar-dynamic';
    if (r.hasPhoto) {
      const img = document.createElement('img');
      img.src = JACOB_PHOTO_SRC;
      img.alt = r.name;
      avatar.appendChild(img);
    } else {
      avatar.appendChild(document.createTextNode(r.initial));
    }
    const badge = document.createElement('span');
    badge.className = 'revolut-badge-sm';
    badge.textContent = 'R';
    avatar.appendChild(badge);

    const details = document.createElement('div');
    details.className = 'contact-details';
    const nameEl = document.createElement('div');
    nameEl.className = 'contact-name';
    nameEl.textContent = r.name;
    const subEl = document.createElement('div');
    subEl.className = 'contact-tag';
    let sub = `Sent ${appState.currency}${last.amount.toLocaleString('en-GB')}`;
    if (last.time) sub += ` · ${last.time}`;
    if (payments.length > 1) sub += ` · ${payments.length} payments`;
    subEl.textContent = sub;
    details.appendChild(nameEl);
    details.appendChild(subEl);

    row.appendChild(avatar);
    row.appendChild(details);
    row.addEventListener('click', () => {
      openChatView({ name: r.name, tag: r.tag, initial: r.initial, hasPhoto: r.hasPhoto });
    });
    list.appendChild(row);
  });

  section.style.display = shown > 0 ? 'block' : 'none';
}

// 8 Grid Action Buttons
document.querySelectorAll('.grid-item').forEach((item) => {
  item.addEventListener('click', () => {
    const action = item.dataset.action;
    showToast(`Option: ${action.charAt(0).toUpperCase() + action.slice(1)}`);
  });
});

document.getElementById('contactsBanner').addEventListener('click', () => {
  showToast('Contacts permission enabled');
});

document.getElementById('myRevtagCard').addEventListener('click', () => {
  showToast('Revtag link copied to clipboard');
});


// ==========================================================================
// VISUAL VIEWPORT SYNC (native iOS keyboard)
// Full-screen views and sheets follow the *visible* area, so the native keyboard
// pushes the bottom controls (Continue, chips, message bar) up instead of covering them.
// ==========================================================================
(function setupViewportSync() {
  const root = document.documentElement;
  const vv = window.visualViewport;
  let raf = 0;

  function sync() {
    raf = 0;
    const kb = vv ? Math.max(0, window.innerHeight - vv.height - vv.offsetTop) : 0;
    if (kb > 120) {
      // Keyboard is open: pages follow the visible area above it
      root.style.setProperty('--vv-h', vv.height + 'px');
      root.style.setProperty('--vv-top', vv.offsetTop + 'px');
      if (!root.classList.contains('kb-open')) root.classList.add('kb-open');
    } else {
      // No keyboard: pages are plain full-screen (no JS positioning -> nothing can drift)
      root.style.removeProperty('--vv-h');
      root.style.removeProperty('--vv-top');
      if (root.classList.contains('kb-open')) root.classList.remove('kb-open');
    }
  }
  const schedule = () => { if (!raf) raf = requestAnimationFrame(sync); };

  if (vv) {
    vv.addEventListener('resize', schedule);
    vv.addEventListener('scroll', schedule);
  }
  window.addEventListener('orientationchange', schedule);
  sync();

  // Static page stack: only the top-most page is painted, the home screen is hidden underneath
  const pages = [paymentsView, chatView, transferView]; // ordered by z-index
  const sheets = [addMoneySheetBackdrop, settingsSheetBackdrop];
  let wasLocked = false;
  let savedY = 0;

  function setClass(el, name, on) {
    if (el.classList.contains(name) !== on) el.classList.toggle(name, on);
  }

  function updateLayers() {
    const activePages = pages.filter((el) => el.classList.contains('active'));
    const top = activePages[activePages.length - 1];
    pages.forEach((el) => setClass(el, 'covered', el.classList.contains('active') && el !== top));

    const pageOpen = activePages.length > 0;
    const sheetOpen = sheets.some((el) => el.classList.contains('open'));
    const locked = pageOpen || sheetOpen;

    if (locked && !wasLocked) savedY = window.scrollY;
    setClass(root, 'view-open', pageOpen);
    setClass(root, 'sheet-open', sheetOpen);
    if (!locked && wasLocked) requestAnimationFrame(() => window.scrollTo(0, savedY));
    wasLocked = locked;
  }

  const observer = new MutationObserver(updateLayers);
  pages.concat(sheets).forEach((el) => observer.observe(el, { attributes: true, attributeFilter: ['class'] }));
  updateLayers();
})();

// Register Service Worker for PWA
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch((err) => {
      console.log('SW registration error:', err);
    });
  });
}

// Initial Render
renderUserInfo();
updateDynamicProfile();
renderBalance();
renderTransactions();
