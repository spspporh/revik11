@echo off
title Revolut iOS PWA Server
cd /d "%~dp0"
node server.js
pause
