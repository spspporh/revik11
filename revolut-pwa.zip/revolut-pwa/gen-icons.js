// Create crisp SVG icons for Apple Touch Icon & PWA
const fs = require('fs');
const path = require('path');

const svgRevolut = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <rect width="512" height="512" rx="115" fill="#000000"/>
  <path d="M160 120h110c55 0 95 32 95 82 0 38-23 68-60 78l70 112h-55l-63-104h-47v104h-50V120zm50 44v84h56c30 0 49-16 49-42s-19-42-49-42h-56z" fill="#ffffff"/>
</svg>`;

fs.writeFileSync(path.join(__dirname, 'assets', 'icon.svg'), svgRevolut);
console.log('Icon SVG generated');
